import { useState } from "react";
import styles from "../styles/Projects.module.css";

const projectData = [
  {
    name: "Musea",
    image: "/assets/musea.jpg", // replace with your actual image
  },
  {
    name: "Elara",
    image: "/assets/elara.jpg",
  },
  {
    name: "Verve",
    image: "/assets/verve.jpg",
  },
  {
    name: "Zephyr",
    image: "/assets/zephyr.jpg",
  },
];

const Projects = () => {
  const [selectedProject, setSelectedProject] = useState(projectData[0]);

  return (
    <div className={styles.projectsContainer}>
      <div className={styles.imageContainer}>
        <img
          src={selectedProject.image}
          alt={selectedProject.name}
          className={styles.projectImage}
        />
      </div>
      <div className={styles.projectList}>
        {projectData.map((project, index) => (
          <button
            key={index}
            onClick={() => setSelectedProject(project)}
            className={`${styles.projectItem} ${
              selectedProject.name === project.name ? styles.active : ""
            }`}
          >
            {project.name}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Projects;
