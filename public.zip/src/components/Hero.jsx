import styles from "../styles/Hero.module.css";

const Hero = () => {
  return (
    <section className={styles.heroSection} id="home">
      <div className={styles.heroContent}>
        {/* Heading */}
        <h1 className={styles.heroTitle}>
          Artist Redefining <br />
          <span className={styles.highlight}>Architecture</span> with <br />
          <span className={styles.bold}>AI-Driven Design</span>
        </h1>

        {/* Description */}
        <p className={styles.heroDescription}>
          Julia Huang is an innovative AI artist, renowned for blending
          cutting-edge technology with creative expression. Based in LA, she
          crafts unique digital art experiences accessible globally.
        </p>
      </div>
    </section>
  );
};

export default Hero;
