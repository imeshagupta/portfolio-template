import styles from "../styles/Navbar.module.css";

const Navbar = () => {
  return (
    <nav className={`navbar navbar-expand-lg ${styles.navbarCustom}`}>
      <div className="container-fluid">
        {/* Brand / Logo */}
        <a className={`navbar-brand ${styles.brand}`} href="#home">
          Julia Huang
        </a>

        {/* Navbar Links */}
        <div className="collapse navbar-collapse justify-content-end">
          <ul className={`navbar-nav ${styles.navLinks}`}>
            <li className="nav-item">
              <a className={`nav-link ${styles.link}`} href="#home">
                Home
              </a>
            </li>
            <li className="nav-item">
              <a className={`nav-link ${styles.link}`} href="#projects">
                Projects
              </a>
            </li>
            <li className="nav-item">
              <a className={`nav-link ${styles.link}`} href="#about">
                About
              </a>
            </li>
            <li className="nav-item">
              <a className={`nav-link ${styles.link}`} href="#contact">
                Contact
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
