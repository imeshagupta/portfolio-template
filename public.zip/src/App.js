import Navbar from "../src/components/Navbar";
import Hero from "../src/components/Hero";
import Contact from "../src/components/Contact";
import SocialLinks from "../src/components/SocialLinks";
import ProfileImg from "../src/components/ProfileImg";
import About from "../src/components/About";
import Projects from "../src/components/Projects";
import "./App.css";

function App() {
  return (
    <div className="App">
      {/* Navbar */}
      <Navbar />

      {/* Hero + ProfileImg side by side */}
      <section id="home" className="hero-section">
        <div className="hero-container">
          <Hero />
          <ProfileImg />
        </div>
      </section>

      {/* About Section */}
      <section id="about">
        <About />
      </section>

      {/* Projects Section */}
      <section id="projects">
        <Projects />
      </section>

      {/* Contact + Social Links */}
      <section id="contact" className="contact-section">
        <div className="contact-container">
          <Contact />
          <SocialLinks />
        </div>
      </section>
    </div>
  );
}

export default App;
